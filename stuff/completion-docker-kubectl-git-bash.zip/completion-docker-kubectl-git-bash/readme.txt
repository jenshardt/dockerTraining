Die hier enthaltenen Verzeichniss etc und usr bitte nach 

  C:\Program Files\Git

kopieren (Administrator-Rechte!)
